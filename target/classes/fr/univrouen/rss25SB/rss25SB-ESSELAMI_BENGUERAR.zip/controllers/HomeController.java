package fr.univrouen.rss25SB.controllers;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("TP08", "RSS25SB Service");
        model.addAttribute("version", "1.0.0");
        model.addAttribute("developers", "Abdelhalim ESSELAMI - Mohamed BENGUERAR");
        return "index";
    }

    @GetMapping("/help")
    public String help(Model model) {
        return "help";
    }
}